up::
tags:: #state/seedling #on/cthulhuConfidential 

# Source
A **Source** is an expert in a field ([[Cthulhu Confidential - Investigative Abilities|Investigative Abilities]]) that the player knows and can go to to obtain more information. ==Questions to sources take you out of the current scene to a new scene with the Source==, so better finnish with this scene before calling on a Source.

Sources give you a chance to have a more friendly and relaxed scene to slow down the game and lower the accumulated tension. These scenes should not have high risk or big stakes and the source should be friendly to the player **unless it is the contrary story-wise**.

## References

---
Planted: 2024-05-24
Last tended: 2024-05-24